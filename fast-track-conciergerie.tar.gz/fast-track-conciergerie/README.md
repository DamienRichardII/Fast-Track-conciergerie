# Fast Track Conciergerie — Abidjan

Next.js 16 (App Router) · TypeScript strict · Tailwind 4 · Motion.

## État (Phases 1 à 3 partielles)
- Fait : design system (tokens, Button, Media, Logo, Header/Footer), accueil, 8 pages service (gabarit), build OK.
- À faire : réservation, comptes (Supabase Auth), paiement (couche abstraite + acompte manuel), admin, emails, tests, déploiement.
- Visuels : placeholders « VISUEL DÉMO » — photos réelles à fournir.
- Logo : monogramme vectorisé V0 depuis la maquette (public/brand/monogram.svg) — à valider/remplacer par le fichier source.

## Lancer
npm install && npm run dev   # puis http://localhost:3000
npm run build
