# Fast Track Conciergerie — Abidjan

Next.js 16 (App Router) · TypeScript strict · Tailwind 4 · Motion.

## État (Phases 1 à 4 — mode demande sur devis)
- Fait : design system (tokens, Button, Media, Logo, Header/Footer), accueil, 8 pages service (gabarit), build OK.
- Fait aussi : parcours de réservation (prestation → dates souhaitées → infos → récapitulatif → confirmation avec référence), calendrier, Destinations, À propos, Contact, pages légales provisoires (noindex), sitemap/robots.
- Les demandes sont enregistrées (JSON local en dev) et/ou envoyées par email (Resend). Sans stockage ni email configuré en production, le formulaire affiche une erreur au lieu d'une fausse confirmation.
- Le calendrier collecte des dates SOUHAITÉES ; aucune disponibilité n'est affichée tant que le back-office ne les configure pas.
- À faire : comptes (Supabase Auth), paiement (couche abstraite + acompte manuel), admin, emails, tests, déploiement.
- Visuels : placeholders « VISUEL DÉMO » — photos réelles à fournir.
- Logo : monogramme vectorisé V0 depuis la maquette (public/brand/monogram.svg) — à valider/remplacer par le fichier source.

## Lancer
npm install && npm run dev   # puis http://localhost:3000
npm run build

## Tests
npm test   # 16 tests Vitest (validation, calendrier, référence, stockage, anti-abus, email)

## Validation client sur Vercel (frontend seul)
1. Dézipper, puis `git remote add origin <url-du-depot>` et `git push -u origin main` (le dépôt Git local contient déjà l'historique).
2. Vercel > Add New > Project > importer le dépôt (Next.js détecté automatiquement).
3. Variables d'environnement : `DEMO_MODE=true` et `NEXT_PUBLIC_SITE_URL=https://<url-vercel>`.
4. Deploy. Les formulaires aboutissent en mode démonstration : l'interface indique que RIEN n'est transmis.
5. Les écrans Espace client, Back-office, Connexion et Paiement sont des aperçus (données fictives, noindex).
Retirer `DEMO_MODE` et configurer Resend/base de données avant toute mise en production réelle.
